from maze import *
from exception import *
from stack import *
class PacMan:
    def __init__(self, grid : Maze) -> None:
        ## DO NOT MODIFY THIS FUNCTION
        self.navigator_maze = grid.grid_representation
   # def find_path(self, start : tuple[int, int], end : tuple[int, int]) -> list[tuple[int, int]]:
        # IMPLEMENT FUNCTION HERE
    def find_path(self, start : tuple, end : tuple) -> list:
        rows = len(self.navigator_maze)
        col = len(self.navigator_maze[0])
        stack = Stack()
        stack.push(start)
        reached= set()
        reached.add(start)

        while not stack.isEmpty():
            x, y = stack.top()

            if (x, y) == end:
                return stack.data

            moved = False

            if self.check_up(x, y) and (x-1, y) not in reached:
                self.move_up(x, y, stack)
                reached.add((x-1, y))
                moved = True

            elif self.check_down(x, y) and (x+1, y) not in reached:
                self.move_down(x, y, stack)
                reached.add((x+1, y))
                moved = True

            elif self.check_left(x, y) and (x, y-1) not in reached:
                self.move_left(x, y, stack)
                reached.add((x, y-1))
                moved = True

            elif self.check_right(x, y) and (x, y+1) not in reached:
                self.move_right(x, y, stack)
                reached.add((x, y+1))
                moved = True

            if not moved:
                self.reverse(stack)

        raise PathNotFoundException()

    def move_up(self, x, y, stack):
        stack.push((x-1, y))

    def move_down(self, x, y, stack):
        stack.push((x+1, y))

    def move_left(self, x, y, stack):
        stack.push((x, y-1))

    def move_right(self, x, y, stack):
        stack.push((x, y+1))

    def check_up(self, x, y):
        return x > 0 and self.navigator_maze[x-1][y] == 0

    def check_down(self, x, y):
        return x < len(self.navigator_maze) - 1 and self.navigator_maze[x+1][y] == 0

    def check_left(self, x, y):
        return y > 0 and self.navigator_maze[x][y-1] == 0

    def check_right(self, x, y):
        return y < len(self.navigator_maze[0]) - 1 and self.navigator_maze[x][y+1] == 0

    def reverse(self, stack):
        stack.pop()

    def check_dead_end(self, x, y):
        if not (self.check_left(x, y) or self.check_right(x, y) or self.check_up(x, y) or self.check_down(x, y)):
            """self.navigator_maze[x][y] = 1
            self.stack.pop()"""
            return True
        return False